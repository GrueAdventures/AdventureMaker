define(function() {
    var exports = {};

    exports.initialize = function() {

    };

    exports.say = function() {

    };

    exports.stop = function() {

    };

    exports.update = function() {

    };

    exports.can_say = function() {
        return false;
    };

    return exports;
});