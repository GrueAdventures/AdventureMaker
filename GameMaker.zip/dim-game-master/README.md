This project is a web-based reboot of the Descent Into Madness audio horror game by Eden Kung and Matt Clark (http://www.cs.unc.edu/Research/assist/et/2005/SoundsLikeFun.html, https://github.com/gbishop/DescentIntoMadness).

I have two goals in doing this port:

1. To resurrect an entertaining audio game for kids with visual impairments to enjoy
2. To build a declarative "choose your own adventure" game engine for would-be audio game writers to use

The port is not yet finished and the game is not yet winnable. Also, the game engine is pretty baked into the game itself and requires some cleanup before its reusable. I plan to meet goal #1 first then worry about #2. See the TODO file for more details.

See the LICENSE file for credit where credit is due.

If you'd like to help bring this project to fruition, ping me.